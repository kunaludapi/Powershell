#<#
Clear-Host

$notExist = $true
$pingIteration = 1
do {
    Write-Host -ForegroundColor Cyan "- Ping Interation: $pingIteration"
    $rackUnits = Import-CSV $PSScriptRoot\RackServers.csv
    # $allServerList = $rackUnits | Group-Object hostName #Select-Object -Unique ServerName
    $nonEmptyServerList = $rackUnits | where-Object {$_.fetchInfo -eq 'yes'} 
    
    Get-Job | Remove-Job -Force -Confirm:$false

    $nonEmptyServerList | ForEach-Object { #-ThrottleLimit 10 -Parallel {
        $null = Start-ThreadJob {
            #$argServerName = $args[0]
            try {
                $pingTest = Test-Connection -TargetName $args[0] -Count 1 -ErrorAction Stop
                [PSCustomObject]@{
                    #New-Object psobject -Property[ordered]@{ 
                    id = $pingTest.Destination
                    hostName = $args[1]
                    name = $pingTest.Destination
                    ipaddress = ($null -ne $pingTest.Address) ? $pingTest.Address.IPAddressToString : $pingTest.Destination
                    status = ($pingTest.Status.ToString() -eq 'Success') ? 'up' : 'down'
                } #[PSCustomObject]@{
            } #try {
            catch {
                [PSCustomObject]@{
                    id = $args[0]
                    hostName = $args[1]
                    name = $args[0]
                    ipaddress = 'Unknown'
                    status = 'unknown'
                }
            } #catch {
            finally {}
        } -ArgumentList $_.ip.Trim(), $_.hostName.Trim() -ThrottleLimit 10 #$null = Start-ThreadJob
    } #$serverList | ForEach-Object {

    Start-Sleep -Seconds 20
    $masterReport = Get-Job | Wait-Job | Receive-Job #| Select-Object @{N='id'; E={$_.Destination}}, @{N='name'; E={$_.Destination}}, @{N='ipAddress'; E={$_.Address.IPAddressToString}}, @{N='status'; E={($_.Status -eq 'Success') ? 'On' : 'Off'}} #Using the ternary operator syntax
    
    $resourceUsage = Import-Csv  $PSScriptRoot\ResourceUsageInfo.csv
    $information =  New-Object System.Collections.ArrayList
    foreach ($rack in $rackUnits)
    {
        if ($rack.hostName -in $masterReport.hostName)
        {
            $matchReport = $masterReport | Where-object {$_.hostName -eq  $rack.hostName }
            $matchUsageReport = $resourceUsage | Where-object {$_.hostName -eq  $rack.hostName }
        }
        else {
            $matchReport = [PSCustomObject]@{
                id = 'n/a'
                hostName = 'n/a'
                name = 'n/a'
                ipaddress = 'n/a'
                status = 'n/a'
            }

            $matchUsageReport = [PSCustomObject]@{
                id = 'n/a'
                hostName = 'n/a'
                name = 'n/a'
                ipaddress = 'n/a'
                cpuusage = 0
                memoryusage = 0
                diskusage = 0
            }
        }
        $rackInfo = @{}
        $rack.psobject.properties | Foreach-Object { $rackInfo[$_.Name] = $_.Value }

        $serverInfo = @{}
        $matchReport.psobject.properties | Foreach-Object { $serverInfo[$_.Name] = $_.Value }
        [void]$rackInfo.Add('serverinfo', $serverInfo)

        $usageInfo = @{}
        $matchUsageReport.psobject.properties | Foreach-Object { $usageInfo[$_.Name] = $_.Value }
        [void]$rackInfo.Add('usageinfo', $usageInfo)

        [void]$information.Add($rackInfo)
    }

    $information | ConvertTo-Json | Out-File $PSScriptRoot\dbase\data.json
    $pingIteration++
} while (
    # Condition that stops the loop if it returns false 
    $notExist -eq $true
) #while (
#>