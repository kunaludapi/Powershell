// Function to fetch data from JSON file
function fetchData() {
  fetch(`dbase/data.json?timestamp=${Date.now()}`, {
      cache: 'no-store' // Set cache to 'no-store' to prevent caching
  })
  .then(response => {
      // Ensure cache control headers are set
      const headers = new Headers(response.headers);
      headers.append('Cache-Control', 'no-cache, no-store, must-revalidate');
      headers.append('Pragma', 'no-cache');
      headers.append('Expires', '0');

      // Create a new Response object with updated headers
      const updatedResponse = new Response(response.body, {
          status: response.status,
          statusText: response.statusText,
          headers: headers
      });

      return updatedResponse.json();
  })
  .then(data => {

    // startregopm Update the live data text status
    for (let i = 0; i < data.length; i++) {
      let server = data[i];
      let element = document.getElementById(server.statusId);
      if (server.fetchInfo === 'yes') {
        // console.log(server)
        if (server.serverinfo.status === 'up') {
          //element.textContent = server.racknumber;
          element.style.color = "#008000";
        } else { //if (server.status === 'up') {
            element.style.color = "#FF0000";
        } //if (server.status === 'up') {
      } 
      
      if (server.isEmpty === 'no' && server.fetchInfo === 'no'){
        element.style.display = 'none';
      } // if (server.isempty === 'no'){ //if (server.fetchInfo === 'yes') {
    } //for (let i = 0; i < data.length; i++) {
     // endregopm Update the live data text status

  }) //.then(data => {
  .catch(error => console.error('Error fetching data:', error));
}

// Function to fetch data initially and then update every 2 seconds
function fetchDataAndRefresh() {
  // Fetch data initially
  fetchData();

  // Update data every 2 seconds
  setInterval(fetchData, 2000);
}

// Start the initial fetch and refresh
fetchDataAndRefresh();

// startregion - info click show data
function showInfo(element) {
  const serverId = element.getAttribute('data-id');
  const tableId = element.getAttribute('data-table');

  //document.getElementById('showtable1').style.display = 'none';

  fetch(`dbase/data.json?timestamp=${Date.now()}`, {
    cache: 'no-store' // Set cache to 'no-store' to prevent caching
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json(); // Parse JSON response
  })
  .then(data => {
    //Start piechart
    function generatePieChart(id, percentage, color, additionalText) {
      const pieChart = document.getElementById(id);
      pieChart.style.setProperty('--p', percentage);
      pieChart.style.setProperty('--c', color);
      //additional text font size
      pieChart.innerHTML = percentage + "%<br><span style='font-size:10px;'>" + additionalText + "</span>"; //text font size
    } //function generatePieChart(id, percentage, color, additionalText) {
    
    function pieColorChoice(usage) {
      if (usage <= 10) {
        return '#00FF00'; // Green
      } else if (usage <= 20) {
        return '#33FF00';
      } else if (usage <= 30) {
        return '#66FF00';
      } else if (usage <= 40) {
        return '#99FF00';
      } else if (usage <= 50) {
        return '#CCFF00';
      } else if (usage <= 60) {
        return '#FFFF00'; // Yellow
      } else if (usage <= 70) {
        return '#FFCC00';
      } else if (usage <= 80) {
        return '#FF9900';
      } else if (usage <= 90) {
        return '#FF6600';
      } else {
        return '#FF3300'; // Red
      }
    } //function pieColorChoice()
    //end piechart


    function generateProgress(id, percentage, color) {
      const progressChart = document.getElementById(id);
      progressChart.value = percentage;
      progressChart.style.accentColor = color;
    } //function generatePieChart(id, percentage, color, additionalText) {    
   
    // Find the server record in the JSON data
    //console.log(data[0])
    const server = data.find(item => item.showTableId === serverId);
    if (server) {
      // Update table for the server
      document.getElementById('inforackno').textContent = server.unitId;
      document.getElementById('hostname').textContent = server.hostName;
      document.getElementById('ip').textContent = server.ip;
      document.getElementById('servericon').src = "img/" + server.serverIcon;
      document.getElementById('osicon').src = "img/" + server.osIcon;
      document.getElementById('project').textContent = server.project;
      document.getElementById('owner').textContent = server.owner;
      document.getElementById('srno').textContent = server.srNo;
      document.getElementById('os').textContent = server.os;
      document.getElementById('osversion').textContent = server.osVersion;
      document.getElementById('make').textContent = server.make;
      document.getElementById('model').textContent = server.model;
      document.getElementById('cpu').textContent = server.cpu;
      document.getElementById('memory').textContent = server.memory;

      if (server.fetchInfo === 'yes')
      {
        //start piechart
        generatePieChart('piecpu',server.usageinfo.cpuusage,pieColorChoice(server.usageinfo.cpuusage),'CPU');
        generatePieChart('piememory',server.usageinfo.memoryusage,pieColorChoice(server.usageinfo.memoryusage),'MEMORY');
        generateProgress('progressstorage',server.usageinfo.diskusage,pieColorChoice(server.usageinfo.diskusage));
        document.getElementById('progressstoragelabel').textContent = server.usageinfo.diskusage + '%';
        //end piechart
      } // if (server.fetchInfo === 'yes')
      else {
        generatePieChart('piecpu',0,'gray','CPU');
        generatePieChart('piememory',0,'gray','MEMORY');
        generateProgress('progressstorage',5,'gray');
      }

    } else { //if (server) {
        console.error('Server information not found for the given ID:', serverId);
    } //if (server) { //else



  })
  .catch(error => console.error('Error fetching data:', error));
} //showInfo()

// endregion - info click show data

//startregion - Show default percentage for blank slot
function generatePieChart(id, percentage, color, additionalText) {
  const pieChart = document.getElementById(id);
  pieChart.style.setProperty('--p', percentage);
  pieChart.style.setProperty('--c', color);
  //additional text font size
  pieChart.innerHTML = percentage + "%<br><span style='font-size:10px;'>" + additionalText + "</span>"; //text font size
}

generatePieChart('piecpu',0,'gray','CPU')
generatePieChart('piememory',0,'gray','MEMORY')
// endregion - Show default percentage for blank slot