#<#
Clear-Host
#$winServer = '172.17.250.172'
$microsoftUser = '.\supermas'
$microsoftPass = 's#rT9012'


#$esxiserver = '172.17.250.58'
$vmwareUser = 'root'
$vmwarePass = '$hr!RaM22j24'

    Write-Host -ForegroundColor Cyan "- Ping Interation: $pingIteration"
    $rackUnits = Import-CSV $PSScriptRoot\RackServers.csv
    # $allServerList = $rackUnits | Group-Object hostName #Select-Object -Unique ServerName
    $nonEmptyServerList = $rackUnits | where-Object {$_.fetchInfo -eq 'yes'} 
    
    #Get-Job | Remove-Job -Force -Confirm:$false

    $report = $nonEmptyServerList | ForEach-Object { #-ThrottleLimit 10 -Parallel {
        #$null = Start-ThreadJob {
            #$argServerName = $args[0]
            try {
                

                if ($_.os.Trim() -eq 'Microsoft') 
                {
                    $secureStringPass = ConvertTo-SecureString $microsoftPass -AsPlainText -Force 
                    $credential = [pscredential]::new($microsoftUser,$secureStringPass) #.GetNetworkCredential().Password

                    $session = New-PSSession -ComputerName $_.ip.Trim() -Credential $credential -ErrorAction Stop
                    $command = { 
                        $Processor = (Get-WmiObject -Class win32_processor -ErrorAction Stop | Measure-Object -Property LoadPercentage -Average | Select-Object Average).Average
                        $ComputerMemory = Get-WmiObject -Class win32_operatingsystem -ErrorAction Stop
                        $Memory = ((($ComputerMemory.TotalVisibleMemorySize - $ComputerMemory.FreePhysicalMemory)*100)/ $ComputerMemory.TotalVisibleMemorySize) 
                        $RoundMemory = [math]::Round($Memory, 2)
                        $localWinDisks =  Get-WmiObject -Class Win32_LogicalDisk | Where-Object {$_.DriveType -eq 3}
                        $calculatedWinDisks = $localWinDisks | Measure-Object -Property Size, FreeSpace -Sum
                        $totalDiskSize = $calculatedWinDisks | Where-Object {$_.Property -eq 'Size'} | Select-Object -ExpandProperty Sum
                        $freeSpaceDisk = $calculatedWinDisks | Where-Object {$_.Property -eq 'FreeSpace'} | Select-Object -ExpandProperty Sum
                        $usedSpaceDisk = $totalDiskSize - $freeSpaceDisk
                        $storageUsagePercent = ($usedSpaceDisk / $totalDiskSize) * 100

                        
                        [PSCustomObject]@{
                            cpuUsage = [int]$Processor
                            memoryUsage = [int]$RoundMemory
                            diskUsage = [System.Math]::Ceiling($storageUsagePercent)
                        }
                    } 
                    $usage = Invoke-Command -Session $session -ScriptBlock $command -ErrorAction Stop

                    [PSCustomObject]@{
                        #New-Object psobject -Property[ordered]@{ 
                        id = $_.ip.Trim()
                        hostName = $_.hostName.Trim()
                        name = $_.ip.Trim()
                        ipaddress = $_.ip.Trim()
                        cpuusage = $usage.cpuUsage
                        memoryusage = $usage.memoryUsage
                        diskusage = $usage.diskUsage
                    } #[PSCustomObject]@{
                }
                elseif ($_.os.Trim() -eq 'VMware') 
                {
                    $esxiLogin = Connect-VIserver -Server $_.ip.Trim() -User $vmwareUser -Password $vmwarePass -ErrorAction Stop
                    $esxi = Get-VMHost #$args[0]
                    $cpuUsagePercent = ($esxi.CpuUsageMhz / $esxi.CpuTotalMhz) * 100
                    $totalMemoryGB = [System.Math]::Round($esxi.MemoryTotalGB/1000,2)
                    $usedMemoryGB = [System.Math]::Round($esxi.MemoryUsageGB/1000,2)
                    $memoryUsagePercent = ($usedMemoryGB / $totalMemoryGB) * 100

                    $datastores =  $esxi | Get-Datastore
                    $calculatedDatastore =  $datastores | Measure-Object -Property CapacityGB, FreeSpaceGB -Sum
                    $totalCapacityGBDS = $calculatedDatastore | Where-Object {$_.Property -eq 'CapacityGB'} | Select-Object -ExpandProperty Sum
                    $freeCapacityGBDS = $calculatedDatastore | Where-Object {$_.Property -eq 'FreeSpaceGB'} | Select-Object -ExpandProperty Sum
                    $usedSpaceGBDS = $totalCapacityGBDS - $freeCapacityGBDS
                    $datastorageUsagePercent = ($usedSpaceGBDS / $totalCapacityGBDS) * 100

                    [void]$esxiLogin    
                    [PSCustomObject]@{
                        id = $_.ip.Trim()
                        hostName = $_.hostName.Trim()
                        name = $_.ip.Trim()
                        ipaddress = $_.ip.Trim()
                        cpuusage = [int]$cpuUsagePercent
                        memoryusage = [System.Math]::Ceiling($memoryUsagePercent)
                        diskusage = [System.Math]::Ceiling($datastorageUsagePercent)
                    } #[PSCustomObject]@{
                    Disconnect-VIServer * -Confirm:$false -ErrorAction SilentlyContinue
                }
                else
                {
                    [PSCustomObject]@{
                        #New-Object psobject -Property[ordered]@{ 
                        id = $_.ip.Trim()
                        hostName = $_.hostName.Trim()
                        name = $_.ip.Trim()
                        ipaddress = $_.ip.Trim()
                        cpuusage = 0
                        memoryusage = 0
                        diskusage = 0
                    } #[PSCustomObject]@{
                }
            } #try {
            catch {
            <#
                $obj = New-Object psobject
                $obj | Add-Member -Name id -MemberType NoteProperty -Value $_.ip.Trim()
                $obj

                [PSCustomObject]@{
                    #New-Object psobject -Property[ordered]@{ 
                    id = $_.ip.
                    hostName = $_.hostName
                    name = $_.ip
                    ipaddress = $_.ip
                    cpuusage = 0
                    memoryusage = 0
                    diskusage = 0
                } #[PSCustomObject]@{
            #>    
            } #catch {
            finally {}
        #} -ArgumentList $_.ip.Trim(),$_.os.Trim(),$_.hostName.Trim(), $microsoftUser, $microsoftPass, $vmwareUser, $vmwarePass -ThrottleLimit 10 #$null = Start-ThreadJob
    } #$serverList | ForEach-Object {

    Start-Sleep -Seconds 20
    #$report = Get-Job | Wait-Job | Receive-Job #| Select-Object @{N='id'; E={$_.Destination}}, @{N='name'; E={$_.Destination}}, @{N='ipAddress'; E={$_.Address.IPAddressToString}}, @{N='status'; E={($_.Status -eq 'Success') ? 'On' : 'Off'}} #Using the ternary operator syntax
    $report | Export-CSV $PSScriptRoot\ResourceUsageInfo.csv -NoTypeInformation

    # $information =  New-Object System.Collections.ArrayList
    # foreach ($rack in $rackUnits)
    # {
    #     if ($rack.hostName -in $report.hostName)
    #     {
    #         $matchReport = $report | Where-object {$_.hostName -eq  $rack.hostName }
    #     }
    #     else {
    #         $matchReport = [PSCustomObject]@{
    #             id = 'N/A'
    #             hostName = 'N/A'
    #             name = 'N/A'
    #             ipaddress = 'N/A'
    #             cpuusage = 0
    #             memoryusage = 0
    #             diskusage = 0
    #         }
    #     }
    #     $rackInfo = @{}
    #     $serverInfo = @{}
    #     $rack.psobject.properties | Foreach-Object { $rackInfo[$_.Name] = $_.Value }
    #     $matchReport.psobject.properties | Foreach-Object { $serverInfo[$_.Name] = $_.Value }
    #     [void]$rackInfo.Add('serverinfo', $serverInfo)
    #     [void]$information.Add($rackInfo)
    # }

    # $information | ConvertTo-Json | Out-File $PSScriptRoot\dbase\data.json
    # $pingIteration++
# } while (
#     # Condition that stops the loop if it returns false 
#     $notExist -eq $true
# ) #while (
#>