$ProcessByCount = Get-Process | Group-Object -Property Name | Sort-Object -Property Count -Descending | Select-Object -First 5
$Top5ProcName = ($ProcessByCount.Name | ForEach-Object {"'{0}'" -f $_}) -join ', '
$Top5ProcCount = ($ProcessByCount | Select-Object -ExpandProperty Count) -join ', '
$LegendLabel = 
$Chart = @"
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script> -->
  <script src="JSScripts/Chart.min.js"></script>
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="JSScripts/bootstrap.min.css">
  <title>Bar Chart</title>
</head>
<body>
  <div class="container">
    <canvas id="myChart"></canvas>
  </div>

  <script>
    let myChart = document.getElementById('myChart').getContext('2d');

    // Global Options
    //Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 12;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'bar', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        //labels:['Boston', 'CA', 'PF', 'LG', 'TS'],
        labels:[$Top5ProcName],
        datasets:[{
          label:'Population',
          //data:[617594, 181045, 153060, 106519, 105162, ],
          data:[$Top5ProcCount],
          backgroundColor:'rgba(0,191,255, 0.6)',
          //backgroundColor:[
          //  'rgba(255, 99, 132, 0.6)',
          //  'rgba(54, 162, 235, 0.6)',
          //  'rgba(255, 206, 86, 0.6)',
          //  'rgba(75, 192, 192, 0.6)',
          //  'rgba(153, 102, 255, 0.6)',
          //  'rgba(255, 159, 64, 0.6)',
          //  'rgba(255, 99, 132, 0.6)'
          //],
		  hoverBackgroundColor: 'rgba(255,165,0, 0.6)',
          borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:3,
          hoverBorderColor:'#000',
		  fontsize:10,
        }]
      },
      options:{
        title:{
          display:false,
          //text:'Largest Cities In Massachusetts',
          fontSize:8
        },
        legend:{
          display:false,
          position:'bottom',
		  labels:{
            fontColor:'Gray',
			fontSize:12,
          }
        },
        layout:{
          padding:{
            left:0,
            right:0,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true,
		  titleFontSize:10
        },
		
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: false,
					display: true, //label show\hide
					//fontColor: 'white',
					fontSize:10,
					//steps: 90000,
					//stepValue: 10000,
					//suggestedMin: 90000,    // minimum will be 0, unless there is a lower value.
					//min: 50000,
					//max: 650000
					//http://www.chartjs.org/docs/latest/axes/cartesian/linear.html	
                },
                gridLines: {
                    //color: "rgba(0, 0, 0, 0)",
					//lineWidth: 0
					display:true,
					drawBorder: true,
                }
            }],
            xAxes: [{
                // Change here
            	barPercentage: 1,
				ticks:{
					//fontColor: 'white',
					fontSize: 12, 
					display: true, //label show\hide
				},
				gridLines: {
                    //color: "rgba(0, 0, 0, 0)",
					//lineWidth: 0
					display:true, 
					drawBorder: true,
                }
            }]
        }		
      }
    });
  </script>
</body>
</html>
"@

$Chart | Out-File -FilePath C:\temp\test.html
Invoke-Expression C:\temp\test.html