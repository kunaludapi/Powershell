﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Console.Write("Current Date and Time is : ");
            //DateTime now = DateTime.Now;
            // Console.WriteLine(now);
            //Console.ReadLine();
            currentDateTime.Text = DateTime.Now.ToString();

            //Date
            int i;
            int[] dateArray = new int[32];
            for (i = 1; i < 32; i++)
            {
                dateArray[i] = i;
            }
            
            foreach (int x in dateArray)
            {
                dateComboBox.Items.Add(x);
            }

            //Month
            int[] monthArray = new int[13];
            for (i = 1; i < 13; i++)
            {
                monthArray[i] = i;
            }

            foreach (int x in monthArray)
            {
                monthComboBox.Items.Add(x);
            }

            //Year
            int[] yearArray = new int[2021];
            for (i = 1920; i < 2020; i++)
            {
                yearArray[i] = i;
            }

            foreach (int x in yearArray)
            {
                yearComboBox.Items.Add(x);
            }

                // do something
                //var today = DateTime.Today;
                //int yearDOB = int.Parse(yearComboBox.SelectedItem.ToString());
                //var age = today.Year - yearDOB;
                //Calculate Age

        }

        private void calculateAge_click(object sender, RoutedEventArgs e)
        {
            result.Text = yearComboBox.SelectedItem.ToString();
        }
    }
}
