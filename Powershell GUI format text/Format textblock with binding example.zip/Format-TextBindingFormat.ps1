[void][System.Reflection.Assembly]::LoadWithPartialName('PresentationFramework')

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" x:Name="MainWindow"
        Title="Text Fomrmatting with Binding" Height="350" Width="500">

    <Grid Margin="10">
        <Button Content="Button" HorizontalAlignment="Left" Margin="10,10,0,0" VerticalAlignment="Top" Height="23" Width="75"/>
        <TextBox HorizontalAlignment="Left" Height="23" Margin="90,10,0,0" TextWrapping="Wrap" Text="TextBox" VerticalAlignment="Top" Width="146"/> 
        <ItemsControl Name='ItemsControl' ItemsSource="{Binding Bindedinfo}"  Margin="0,38,0,0">
            <ItemsControl.ItemTemplate>
                <DataTemplate>
                    <Grid Margin="5">
                        <Grid.ColumnDefinitions>
                                <ColumnDefinition Width="250" />
                                <ColumnDefinition Width="100" />
                                <ColumnDefinition Width="Auto" />
                        </Grid.ColumnDefinitions>
                        <TextBlock Name='Displayname' Grid.Column="0" Text="{Binding Path=DisplayName}"/>
                        <TextBlock Name='Status' Grid.Column="1" Text="{Binding Path=Status}"/>
                        <TextBlock Name='StartType' Grid.Column="2" Text="{Binding Path=StartType}" />
                    </Grid>
                </DataTemplate>
            </ItemsControl.ItemTemplate>
        </ItemsControl>
    </Grid>
</Window>
"@

#Read XAML
$Form = [Windows.Markup.XamlReader]::Parse($xaml)

$Code = {
    <#
        $ColorObj = New-Object System.Windows.Media.SolidColorBrush
        $ColorObj.Color = 'DarkGreen'
        $ColorObj
        #-------------
        [System.Windows.Media.Colors]::Green
        [System.Windows.Media.Brushes]::Green
    #>
    if ($_.Status -eq 'Running') {
        '[System.Windows.Media.Brushes]::Green'
    }
    else {
        'Red'
    }
}
$Services = Get-Service | Select-Object DisplayName, Status, StartType, @{N='Foreground';E={& $Code}} -First 10
$ServicesData = New-Object PSObject -Property @{Bindedinfo = $Services}
#$Form.DataContext = $ServicesData
$ServicesData | ForEach-Object {$Form.DataContext = $_}

#Read Form
[system.void]$Form.ShowDialog()

<#
$CompleteInfo = @()
foreach ($service in $services) {
    $CompleteInfo += @(    
        New-Object PSObject -Property @{ 
            ServiceName = $service.DisplayName
            ServiceStatus = $service.Status
            StartType = $service.StartType
        };
    )
}
#>