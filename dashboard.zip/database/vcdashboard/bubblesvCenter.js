var vCenters = [
  {
  	"vCenterCount": 171,
	"CountryName": "UNITED STATES",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 65,
	fillKey: 'USA',
	latitude: 44.18,
	longitude: -95.50
  },
  {
  	"vCenterCount": 31,
	"CountryName": "MEXICO",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 50,
	fillKey: 'MEX',
	latitude: 19.432,
	longitude: -99.133
  },  
  {
	"vCenterCount": 1,
	"CountryName": "AUSTRALIA",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center",	
	radius: 15,
	fillKey: 'AUS',
	latitude: -35.47,
	longitude: 149.01
  },
  {
  	"vCenterCount": 1,
	"CountryName": "INDONESIA",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center",	
	radius: 15,
	fillKey: 'IDN',
	latitude: 0.78,
	longitude: 113.9

  },
{
  	"vCenterCount": 1,
	"CountryName": "Unknown",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 15,
	fillKey: 'IND',
	latitude: -30.00,
	longitude: -110.00
  },  
  {
  	"vCenterCount": 1,
	"CountryName": "India",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 15,
	fillKey: 'IND',
	latitude: 21.00,
	longitude: 78.00
  },
  {
  	"vCenterCount": 1,
	"CountryName": "TAIWAN",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 15,
	fillKey: 'TWN',
	latitude: 25.10,
	longitude: 121.59
  },
  {
  	"vCenterCount": 6,
	"CountryName": "CHINA",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 19,
	fillKey: 'CHN',
	latitude: 35.10,
	longitude: 105.00
  },
  {
  	"vCenterCount": 6,
	"CountryName": "REPUBLIC OF KOREA",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 20,
	fillKey: 'KOR',
	latitude: 37.532,
	longitude: 127.024
  },
  {
  	"vCenterCount": 20,
	"CountryName": "HONG KONG",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 30,
	fillKey: 'HKG',
	latitude: 22.28,
	longitude: 114.14
  },
  {
  	"vCenterCount": 22,
	"CountryName": "SINGAPORE",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 30,
	fillKey: 'SGP',
	latitude: 1.29,
	longitude: 103.85
  },
  {
  	"vCenterCount": 25,
	"CountryName": "UNITED KINGDOM",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 45,
	fillKey: 'GBR',
	latitude: 51.50,
	longitude: -0.11
  },
  {
  	"vCenterCount": 26,
	"CountryName": "GERMANY",
	"City": "RUTHERFORD, NEW YORK, GEORGETOWN, DELAWARE, ROANOKE",
	"SiteCategory": "Data Center, Lab",	
	radius: 45,
	fillKey: 'GBR',
	latitude: 51.164,
	longitude: 10.4541
  }
 
];