var vCenters = [{
	name: 'Joe 4',
	radius: 25,
	yeild: 400,
	country: 'USSR',
	fillKey: 'RUS',
	significance: 'First fusion weapon test by the USSR (not "staged")',
	date: '1953-08-12',
	latitude: 50.07,
	longitude: 78.43
  },{
	name: 'RDS-37',
	radius: 40,
	yeild: 1600,
	country: 'USSR',
	fillKey: 'RUS',
	significance: 'First "staged" thermonuclear weapon test by the USSR (deployable)',
	date: '1955-11-22',
	latitude: 50.07,
	longitude: 78.43

  },{
	name: 'Tsar Bomba',
	radius: 75,
	yeild: 50000,
	country: 'USSR',
	fillKey: 'RUS',
	significance: 'Largest thermonuclear weapon ever tested—scaled down from its initial 100 Mt design by 50%',
	date: '1961-10-31',
	latitude: 73.482,
	longitude: 54.5854
  }
,{
	name: 'Test',
	radius: 30,
	yeild: 50000,
	country: 'INDIA',
	fillKey: 'IND',
	significance: 'Largest thermonuclear weapon ever tested—scaled down from its initial 100 Mt design by 50%',
	date: '1961-10-31',
	latitude: 10.482,
	longitude: 54.5854
  }  
];