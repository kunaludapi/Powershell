//Total vCentercount
var totalvcenters = {
	"Description": "Total vCenter count",
	"vcentercount": 308
};

//canchart01 vCenter Countrywise charts lables, decending list
var chartcountrieslables = [
	'United States',
	'MEXICO',
	'GERMANY',
	'UNITED KINGDOM',
	'SINGAPORE',
	'HONG KONG',
	'REPUBLIC OF KOREA',
	'CHINA',
	'AUSTRALIA',
	'INDONESIA',
	'INDIA',
	'UNKNOWN',
	'TAIWAN'	
];

//canchart01 vCenter Countrywise charts data, decending list
var chartcountriesdata = {
	'United STATES': 170,
	'MEXICO': 31,
	'GERMANY': 26,
	'UNITED KINGDOM': 25,
	'SINGAPORE': 22,
	'HONG KONG': 20,
	'REPUBLIC OF KOREA': 6,
	'CHINA': 5,
	'AUSTRALIA': 1,
	'INDONESIA': 1,
	'INDIA': 1,
	'UNKNOWN': 1,
	'TAIWAN': 1
};

//canchart02 vCenter Countrywise charts lables, decending list
var chartregionlables = [
	'North AMERICA',
	'ASIA PACIFIC',
	'EUROPE MIDDLE EAST AND AF',
	'LATIN AMERICA',
	'NA',
	'ASIAPAC',
	'Unknown'	
];

//canchart02 vCenter Countrywise charts data, decending list
var chartregiondata = {
	'North AMERICA': 168,
	'ASIA PACIFIC': 56,
	'EUROPE MIDDLE EAST AND AF': 49,
	'LATIN AMERICA': 31,
	'NA': 2,
	'ASIAPAC': 1,
	'Unknown:': 1	
};

//canchart03 vCenter versions dougnut lables, decending list
var chartversionlables = [
	'6.7.0',
	'6.5.0',
	'Unknown'	
];

//canchart03 vCenter versions charts data, decending list
var chartversiondata = {
	'6.7.0': 168,
	'6.5.0': 56,
	'Unknown:': 1	
};

//canchart03 vCenter versions dougnut lables, decending list
var chartopsstatuslables = [
	'OPERATIONAL',
	'UNDER DEPLOYMENT',
	'Unknown',
	'RETIRED'
];

//canchart03 vCenter versions charts data, decending list
var chartopsstatusdata = {
	'OPERATIONAL': 297,
	'UNDER DEPLOYMENT': 7,
	'Unknown:': 3,
	'RETIRED': 1
};

var vcentercardsdata = {
	'390': 23,
	'FDC': 25,
	'GTDC': 38,
	'HK': 22,
	'JPN': 3,
	'JRDC': 14,
	'KOR': 6,
	'MWDC': 40,
	'QRDC': 17,
	'RDC': 24,
	'RUTH': 27,
	'SG': 10,
	'SG3': 7,
	'SWDC': 43,
	'Techroom': 11,
};
