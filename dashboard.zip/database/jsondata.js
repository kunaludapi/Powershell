var vcenterjsondata = '{"vcenterinventoried":1931,"okvcenter":172,"notokvcenter":22,"noshowhostingvms":18}';
var esxijsondata = '{"totalesxicount":15331,"maintenancemode":195,"notrespondinginvc":47,"esxinotpinging":20,"esxiunknownstatus":11}';
var racjsondata = '{"racpingable":2443,"racnonpingable":254,"racnodns":125,"ibmblades":434}';
var healthsummaryjsondata = '{"notokvcenter":22,"maintenancemode":145,"esxilonoping":125,"unconfiguredilo":98,"alarmdisabled":49,"ntpissues":20,"deadstoragepath":27}';

//For charts if you don't want to use quotes only use below var names as for data "Object.values(barchartjsondata)" and for member properties "Object.keys(barchartjsondata)" 
var barchartjsondata01 = '{"notokvcenter":22,"maintenancemode":145,"esxilonoping":125,"unconfiguredilo":98,"alarmdisabled":49,"ntpissues":20,"deadstoragepath":27}';
var doughnutchartjsondata01 = '{"okvcenter":173,"notokvcenter":20,"noshowhostingvms":19}';