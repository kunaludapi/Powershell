var vcentersummarydata = JSON.parse(vcenterjsondata);
var esxisummarydata = JSON.parse(esxijsondata);
var racsummarydata = JSON.parse(racjsondata);
var healthsummarydata = JSON.parse(healthsummaryjsondata);

//Charts not required but keeping but I will be using same data in left side array queue row.
var barchartdata01 = JSON.parse(barchartjsondata01);
var doughnutchartdata01 = JSON.parse(doughnutchartjsondata01);
//alert(data.foo);
