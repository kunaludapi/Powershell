#Load required libraries
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing 
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

$formData = Get-Content -Path G:\Projects\CitiProj\vCenterEsxiReport\FirstSol01\FirstSol01\MainWindow.xaml

[xml]$xaml = $formData  -replace 'mc:Ignorable="d"', '' -replace "x:N", 'N' -replace 'x:Class=".*?"', '' -replace 'd:DesignHeight="\d*?"', '' -replace 'd:DesignWidth="\d*?"', ''

#Read the form
$Reader = (New-Object System.Xml.XmlNodeReader $xaml) 
$Form = [Windows.Markup.XamlReader]::Load($reader) 

#AutoFind all controls
$xaml.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")  | ForEach-Object { 
  New-Variable  -Name $_.Name -Value $Form.FindName($_.Name) -Force
}

$reportFoldersNames = Get-ChildItem "$ScriptPath\InventoryReports" | Sort-Object {$_.Name -as [datetime]} -Descending #| Select-Object -ExpandProperty Name
$reportFileName = $reportFoldersNames | Select-Object -ExpandProperty Name
$comboBoxReportLists.ItemsSource = $reportFileName
$comboBoxReportLists.SelectedIndex = $comboBoxReportLists.items.IndexOf($reportFileName[0])

Function Set-FirstPage {
  [CmdletBinding(
    SupportsShouldProcess=$True,  
    ConfirmImpact='Medium',  
    HelpURI='http://vcloud-lab.com')]  
  Param  
    (  
      [parameter(Position=0, ValueFromPipelineByPropertyName=$true)]  
      [string]$FolderDate = $reportFileName[0]
    ) 

  $vCenterCountReport = Import-Csv -Path "$ScriptPath\InventoryReports\$FolderDate\vCenterCountReport.csv"
  $esxiCountReport = Import-Csv -Path "$ScriptPath\InventoryReports\$FolderDate\EsxiCountReport.csv"

  $textBlockNotOkVC.Text = $vCenterCountReport.NotOk
  $textBlockMaintenanceMode.Text = $esxiCountReport.'Maintenance Mode'
  $textBlockNotResponding.Text = $esxiCountReport.'Not Reponding in VC'
  $textBlockNonPinging.Text = $esxiCountReport.'Not Pinging'
  $textBlockUnKnown.Text = $esxiCountReport.Unknown

  $textBlockvCenterInventory.Text = "Total: `t{0} `nOk: `t{1} `nNotOk: `t{2}" -f $vCenterCountReport.Total, $vCenterCountReport.Ok, $vCenterCountReport.NotOk
  $vCenterInventoryDoughnutNames = "'Ok', 'NotOk'"
  $vCenterInventoryDoughnutCount = "$($vCenterCountReport.Ok), $($vCenterCountReport.NotOk)"
  & "$ScriptPath\ChartScripts\New-DoughnutChart.ps1" -Names $vCenterInventoryDoughnutNames -Count $vCenterInventoryDoughnutCount -LegendLabel 'vCenter Status' -HtmlFileName  vCenterDoughnut
  $webBrowservCenterInventory.Navigate("file:///$ScriptPath\HtmlCharts\vCenterDoughnut.html")

  $textBlockEsxiRCInventory.Text = "Total: `t`t`t{0} `nMaintenance Mode: `t{1} `nNon Responding in VC: `t{2} `nNot Pinging: `t`t{3} `nUnknown: `t`t{4}" -f $esxiCountReport.Total, $esxiCountReport.'Maintenance Mode', $esxiCountReport.'Not Reponding in VC', $esxiCountReport.'Not Pinging', $esxiCountReport.Unknown
  $esxiInventoryDoughnutNames = "'Maintenance', 'NonResponding', 'NonPinging', 'Unknown'"
  $esxiInventoryDoughnutCount = "$($esxiCountReport.'Maintenance Mode'), $($esxiCountReport.'Not Reponding in VC'), $($esxiCountReport.'Not Pinging'), $($esxiCountReport.Unknown)"
  & "$ScriptPath\ChartScripts\New-DoughnutChart.ps1" -Names $esxiInventoryDoughnutNames -Count $esxiInventoryDoughnutCount -LegendLabel 'Esxi Status' -HtmlFileName EsxiDoughnut
  $webBrowserEsxiRCInventory.Navigate("file:///$ScriptPath\HtmlCharts\EsxiDoughnut.html")
}

Set-FirstPage

$comboBoxReportLists.Add_SelectionChanged({ 
  Set-FirstPage -FolderDate $comboBoxReportLists.SelectedItem
})

#Mandetory last line of every script to load form
[void]$Form.ShowDialog()